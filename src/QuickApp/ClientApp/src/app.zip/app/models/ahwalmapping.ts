export class ahwalmapping {
    ahwalID:number;
    sectorID:number;
    cityGroupID:number;
    shiftID:number;
    patrolRoleID:number;
    personID:number;
    ahwalMappingID:number;
}
