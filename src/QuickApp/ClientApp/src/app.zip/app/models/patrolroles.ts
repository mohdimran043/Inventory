export class patrolroles {
    patrolRoleID:number;
    name:string;
}