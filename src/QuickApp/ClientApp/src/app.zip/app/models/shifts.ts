export class shifts {
    shiftID:number;
    name:string;
    startingHour:string;
    numberOfHours:string;
    
}