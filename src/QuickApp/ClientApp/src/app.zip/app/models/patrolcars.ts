export class patrolcars
{
  patrolid:number ;
  platenumber:string;
  ahwalid:number ;
  model: string;
  vinnumber: string;
  typecode:string ;
  type:string;
  defective: number ;

  rental:number ;
  barcode: string;
}



