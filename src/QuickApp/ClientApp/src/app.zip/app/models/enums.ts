// ====================================================

// Email: support@ebenmonney.com
// ====================================================

export enum Gender {
    None,
    Female,
    Male
}
