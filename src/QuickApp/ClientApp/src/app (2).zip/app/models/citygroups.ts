export class citygroups {
    cityGroupID:number;
    ahwalID:number;
    sectorID:number;
    shortName:string;
    callerPrefix:string;
    text:string;
    disabled:number;
}