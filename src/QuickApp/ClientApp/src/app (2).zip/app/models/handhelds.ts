export class handhelds
{
  handheldid:number ;
  serial:string;
  ahwalid:number ;
  barcode: string;
  defective: number ;
}



